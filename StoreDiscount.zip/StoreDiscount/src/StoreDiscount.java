
import java.util.Scanner;

public class StoreDiscount {

    public static void main(String[] args) {
        // Create a scanner object to get user input
        Scanner scanner = new Scanner(System.in);
        
        // Prompt the user for the total purchase amount
        System.out.println("Please enter the total purchase amount (in Rands):");
        double totalAmount = scanner.nextDouble();
        
        // Declare the discount variable
        double discount = 0.0;
        
        // Apply discount rules using nested if-else statements
        if (totalAmount > 1000) {
            discount = 0.20 * totalAmount;  // 20% discount for purchases over 1000 Rands
        } else if (totalAmount > 500) {
            discount = 0.10 * totalAmount;  // 10% discount for purchases over 500 but less than or equal to 1000 Rands
        } else {
            discount = 0.0;  // No discount for purchases 500 Rands or below
        }
        
        // Calculate the final amount after applying the discount
        double finalAmount = totalAmount - discount;
        
        // Display the discount and final amount
        System.out.println("Discount applied: R" + discount);
        System.out.println("Final amount after discount: R" + finalAmount);
        
        // Close the scanner
        scanner.close();
    }
}

